from django.apps import AppConfig


class VisualizedataConfig(AppConfig):
    name = 'visualizedata'
